package src;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
import java.awt.*;
import javax.swing.JFrame;
import java.awt.image.*;
import javax.imageio.*;
import java.util.*;
import java.io.*;

public class WorldMapCanvas extends Canvas{
    
    static BufferedImage img;
    static double latcenter=30,longcenter=-80,termrot=45;
    
    public static void main(String[] args){
        JFrame f = new JFrame("Rotated World Map");
        try{
            img=ImageIO.read(new File(args[0]));//"C:\\Users\\admin\\Desktop\\PolitWM.png"));
        }catch(Exception e){
            System.out.println("Error.");
        }
        latcenter=Double.parseDouble(args[1]);
        longcenter=Double.parseDouble(args[2]);
        termrot=Double.parseDouble(args[3]);
        f.add(new WorldMapCanvas());
        f.setSize(816,439);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true); 
    }
    
    public void paint(Graphics g){
        double x,y,z,x2,y2,z2;
        double lat,lon;
        Color plotThis;
        for(int sx=0; sx<800; sx++)for(int sy=0; sy<400; sy++){
            //Convert pixel to latitude and longitude. 
            lon=(sx-400)*(Math.PI/400);
            lat=(200-sy)*(Math.PI/400);
            //Convert to (x,y,z) coordinates.
            x=Math.cos(lat)*Math.cos(lon);
            y=Math.cos(lat)*Math.sin(lon);
            z=Math.sin(lat);
            //Rotate along axis going through center.
            x2=x;
            y2=y*Math.cos(-termrot*Math.PI/180)-z*Math.sin(-termrot*Math.PI/180);
            z2=z*Math.cos(-termrot*Math.PI/180)+y*Math.sin(-termrot*Math.PI/180);
            //Change latitude.
            x=x2*Math.cos(latcenter*Math.PI/180)-z2*Math.sin(latcenter*Math.PI/180);
            y=y2;
            z=z2*Math.cos(latcenter*Math.PI/180)+x2*Math.sin(latcenter*Math.PI/180);
            //Change longitude.
            x2=x*Math.cos(longcenter*Math.PI/180)-y*Math.sin(longcenter*Math.PI/180);
            y2=y*Math.cos(longcenter*Math.PI/180)+x*Math.sin(longcenter*Math.PI/180);
            z2=z;
            //Convert (x,y,z) coordinates to latitude and longitude.
            lat=Math.atan2(z2, Math.sqrt(x2*x2+y2*y2));
            lon=Math.atan2(y2, x2);
            //Get the color of the corresponding pixel in the original image .
            try{
                g.setColor(new Color(img.getRGB((int)(lon*400/Math.PI+400),(int)(200-lat*400/Math.PI))));
            }catch(Exception e){
                g.setColor(Color.red);
            }
            //Color the screen pixel this color.
            g.drawLine(sx,sy,sx,sy);
        }
    }
    
}
