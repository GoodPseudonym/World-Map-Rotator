/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.IOException;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author admin
 */
public class WorldMapSelector {
    public static void main(String[] args){
        JFrame f = new JFrame("Map and Coordinates");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(null);
        f.setSize(310,335);
        JLabel pathLabel = new JLabel("Enter the path to the map you wish to use:");
        pathLabel.setBounds(5,5,290,30);
        f.add(pathLabel);
        JTextField pathAnswer = new JTextField("");
        pathAnswer.setBounds(10,40,280,30);
        f.add(pathAnswer);
        JButton orUseFileExplorer = new JButton("Or use file navigator");
        orUseFileExplorer.setBounds(50,75,200,30);
        orUseFileExplorer.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                FileNameExtensionFilter filter = new FileNameExtensionFilter(
                    "Images", "jpg", "gif","jpeg","bmp","png");
                chooser.setFileFilter(filter);
                int returnVal = chooser.showOpenDialog(orUseFileExplorer);
                if(returnVal == JFileChooser.APPROVE_OPTION) {
                   pathAnswer.setText(chooser.getCurrentDirectory()+"\\"+chooser.getSelectedFile().getName());
                }
            }
        });
        f.add(orUseFileExplorer);
        JLabel mapRestrictions = new JLabel("<html>Do note that this program is only compatible with 800x800 Equirectangular world maps.");
        mapRestrictions.setBounds(30,110,240,60);
        f.add(mapRestrictions);
        JSeparator bar = new JSeparator(SwingConstants.HORIZONTAL);
        bar.setBounds(5,175,290,5);
        f.add(bar);
        JLabel latq = new JLabel("Latitude of new center:");
        latq.setBounds(5,210,140,20);
        f.add(latq);
        JTextField latAnswer = new JTextField("30");
        latAnswer.setBounds(150,210,40,20);
        f.add(latAnswer);
        ButtonGroup EW=new ButtonGroup();
        JRadioButton E = new JRadioButton("°E");
        E.setBounds(195,185,40,20);
        f.add(E);
        EW.add(E);
        JRadioButton W = new JRadioButton("°W");
        W.setBounds(240,185,45,20);
        f.add(W);
        EW.add(W);
        JLabel lonq = new JLabel("Longitude of new center:");
        lonq.setBounds(5,185,140,20);
        f.add(lonq);
        JTextField lonAnswer = new JTextField("80");
        lonAnswer.setBounds(150,185,40,20);
        f.add(lonAnswer);
        W.setSelected(true);
        ButtonGroup NS=new ButtonGroup();
        JRadioButton N = new JRadioButton("°N");
        N.setBounds(195,210,40,20);
        f.add(N);
        NS.add(N);
        JRadioButton S = new JRadioButton("°S");
        S.setBounds(240,210,45,20);
        f.add(S);
        NS.add(S);
        N.setSelected(true);
        JLabel eDir=new JLabel("Direction of east (degrees above +x):");
        eDir.setBounds(5,235,220,20);
        f.add(eDir);
        JTextField eDirAnswer = new JTextField("-45");
        eDirAnswer.setBounds(230,235,40,20);
        f.add(eDirAnswer);
        JSeparator bar2 = new JSeparator(SwingConstants.HORIZONTAL);
        bar2.setBounds(5,260,290,5);
        f.add(bar2);
        JButton go = new JButton("Generate recentered and rotated map!");
        go.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                double lat,lon,turn;
                if(E.isSelected()){
                    lon=Double.parseDouble(lonAnswer.getText());
                }else{
                    lon=-Double.parseDouble(lonAnswer.getText());
                }
                if(N.isSelected()){
                    lat=Double.parseDouble(latAnswer.getText());
                }else{
                    lat=-Double.parseDouble(latAnswer.getText());
                }
                turn=Double.parseDouble(eDirAnswer.getText());
                WorldMapCanvas.main(new String[]{pathAnswer.getText(),
                    Double.toString(lat),Double.toString(lon),Double.toString(turn)});
            }
        });
        go.setBounds(20,270,260,20);
        f.add(go);
        f.setVisible(true);
    }
}
